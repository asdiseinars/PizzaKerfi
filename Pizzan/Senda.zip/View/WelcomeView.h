#ifndef WELCOMEVIEW_H
#define WELCOMEVIEW_H
#include "PizzaView.h"
#include <iostream>

using namespace std;


class WelcomeView
{
    private:

    public:
        WelcomeView();
        virtual ~WelcomeView();
        void displayWelcome();


};

#endif // WELCOMEVIEW_H
