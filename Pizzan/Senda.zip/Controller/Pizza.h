#ifndef PIZZA_H
#define PIZZA_H


class Pizza
{
    public:
        Pizza();
        virtual ~Pizza();

    protected:

    private:
};

#endif // PIZZA_H
