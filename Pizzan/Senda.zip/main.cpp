#include <iostream>
#include "Welcome.h"
#include "WelcomeView.h"

using namespace std;

int main()
{
    Welcome menu;
    menu.initialize();
    return 0;
}
